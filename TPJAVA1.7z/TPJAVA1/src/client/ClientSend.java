package client;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import common.Message;
import java.io.PrintWriter;
import java.io.DataOutputStream;

public class ClientSend implements Runnable {

	private Socket socket;
	private ObjectOutputStream out;

	public ClientSend(Socket socket, ObjectOutputStream out) {
		super();
		this.socket = socket;
		this.out = out;
	}

	@Override
	public void run() {
		System.out.println("Thread ClientSend en cours");
		Scanner sc = new Scanner(System.in);
		while (true) {
			try {
                System.out.print("Votre message >> ");
                String m = sc.nextLine();

                Message mess = new Message("client", m);

                out.writeObject(mess);
                out.flush();

                System.out.println("message envoyé");
            } catch (IOException ex) {
                Logger.getLogger(ClientSend.class.getName()).log(Level.SEVERE, null, ex);
            }
			}
		}

	}
