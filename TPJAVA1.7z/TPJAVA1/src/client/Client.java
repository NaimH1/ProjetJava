package client;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import client.view.ClientPanel;
import client.view.IHMBuilderControler;
import common.Message;

public class Client {
	private String address;
	private int port;
	private Socket socket;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	private ClientPanel view;
	private IHMBuilderControler iHMBuilderControler;

	public Client(String adress, int port) {
		super();
		this.address = adress;
		this.port = port;

		try {
			socket = new Socket(address, port);
			out = new ObjectOutputStream(socket.getOutputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}

		Thread threadSend = new Thread(new ClientSend(socket, out));
		threadSend.start();

		Thread threadReceive = new Thread(new ClientReceive(this, socket));
		threadReceive.start();

	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String adress) {
		this.address = adress;
	}

	public ObjectInputStream getIn() {
		return in;
	}

	public void setIn(ObjectInputStream in) {
		this.in = in;
	}

	void disconnectedServer() {

		try {

			if (out != null)
				out.close();
			if (in != null)
				in.close();
			if (socket != null)
				socket.close();

			System.exit(0);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void sendMessage(String text) throws IOException {
		Message mess = new Message("client", text);

		out.writeObject(mess);
		out.flush();
	}

	void messageReceived(Message mess) {
		if (this.view != null)
			this.view.printNewMessage(mess);
		else
			this.iHMBuilderControler.printNewMessage(mess);
		System.out.println(mess);
	}

	
	public void setView(ClientPanel clientPanel) {
		this.view = clientPanel;
	}

	public void setViewControler(IHMBuilderControler iHMBuilderControler) {
		this.iHMBuilderControler = iHMBuilderControler;
	}
	
}
