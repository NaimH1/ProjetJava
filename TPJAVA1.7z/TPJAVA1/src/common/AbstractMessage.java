package common;

import java.io.Serializable;

public class AbstractMessage implements Serializable {
	
	public static final long serialVersionUID = 1L;


}
