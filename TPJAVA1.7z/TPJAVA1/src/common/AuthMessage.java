package common;

import java.io.Serializable;

public class AuthMessage extends AbstractMessage implements  Serializable {

	public static final long serialVersionUID = 1L;

	
}
