package server;

import java.util.ArrayList;
import java.util.List;
import common.Message;

public class Server {

	private int port;
	private List<ConnectedClient> clients;

	public Server(int port) {
		super();
		this.port = port;
		clients = new ArrayList<ConnectedClient>();

		Thread ThreadConnection = new Thread(new Connection(this));
		ThreadConnection.start();

	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public List<ConnectedClient> getClients() {
		return clients;
	}

	public void setClients(List<ConnectedClient> clients) {
		this.clients = clients;
	}

	public void addClient(ConnectedClient client) {
		Message mess = new Message("server", "Le client " + client.getId() + " vient de se connecter");
		broadcastMessage(mess, client.getId());
		this.clients.add(client);
	}

	public int getNumClients() {
		return clients.size();
	}

	public void broadcastMessage(Message mess, int id) {

		for (ConnectedClient client : clients) {
			if (client.getId() != id) {
				client.sendMessage(mess);
				System.out.println("message envoy� � " + id);
			}
		}

	}

	public void disconnectedClient(ConnectedClient discClient) {
		clients.remove(discClient);
		discClient.closeClient();

		Message mess = new Message("server", "Le client " + discClient.getId() + " nous a quitt�");
		broadcastMessage(mess, discClient.getId());
	}

}
