package server;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import common.Message;

public class ConnectedClient implements Runnable {

	private Server server;
	private Socket sockNewClient;

	public static int idCounter;
	private int id;
	private ObjectOutputStream out = null;
	private ObjectInputStream in = null;

	public ConnectedClient(Server server, Socket sockNewClient) {
		super();
		this.server = server;
		this.sockNewClient = sockNewClient;
		id = ++idCounter;

		try {
			out = new ObjectOutputStream(sockNewClient.getOutputStream());
			in = new ObjectInputStream(sockNewClient.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Nouvelle connexion, id = " + id);
	}

	public Server getServer() {
		return server;
	}

	public void setServer(Server server) {
		this.server = server;
	}

	public Socket getSockNewClient() {
		return sockNewClient;
	}

	public void setSockNewClient(Socket sockNewClient) {
		this.sockNewClient = sockNewClient;
	}

	@Override
	public void run() {
		System.out.println("Thread -  ConnectedClient en cours");
//		
//		}
		boolean isActive = true;
		while (isActive) {

			Message mess;
			try {

				System.out.println("Ecoute de " + id);
				mess = (Message) in.readObject();

				if (mess != null) {
					mess.setSender(String.valueOf(id));
					System.out.println("Message re�u de " + id + " : " + mess.toString());

					server.broadcastMessage(mess, id);
				} else {
					server.disconnectedClient(this);
					isActive = false;
				}

			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (EOFException e) {
				server.disconnectedClient(this);
				isActive = false;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public void sendMessage(Message mess) {

		try {
			out.writeObject(mess);
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void closeClient() {

		try {
			this.in.close();
			this.out.close();
			this.sockNewClient.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
