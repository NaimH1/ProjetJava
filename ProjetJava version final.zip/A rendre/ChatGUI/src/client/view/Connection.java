package client.view;

import java.net.URL;

import client.network.Client;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;



public class Connection extends Application {

	 @Override
	    public void start(Stage stage) throws Exception {
		 	//Ouverture de la fenêtre de l'écran de connexion
	        Parent root = FXMLLoader.load(getClass().getResource("EcranConnexion.fxml"));
	        stage.setTitle("DelChat - Connexion");
	        stage.setScene(new Scene(root, 800, 500));
	        stage.show();
	    }
	 
	    public static void main(String[] args) {
	        Application.launch(Connection.class, args);
	    }
}
