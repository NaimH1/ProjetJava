package client.view;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import com.bd.Database;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class GameControler implements Initializable {
	
	//Définition des éléments JavaFX
	@FXML
	public Button ruleBtn;

	@FXML
	public Button playBtn;
	
	@FXML
	public Button quitBtn;

	@FXML
	public TableView<ModeleTableScore> table;
	
	@FXML
	public TableColumn<ModeleTableScore, String> col_id;
	
	@FXML
	public TableColumn<ModeleTableScore, String> col_score;
	
	//Création d'une observableList pour l'affichage sur la tableview
	ObservableList<ModeleTableScore> oblist = FXCollections.observableArrayList();
	
	//Id contenant l'identifiant de l'utilisateur connectée
	private String id;
	
	public void myFunction(String text)
	{
		this.id = text;
	}
	
	public String getId()
	{
	return id;	
	}
	
	//Redéfinition de la méthode initialize pour le tableView 
	@Override
	public void initialize(URL arg0, ResourceBundle resources) {
		//CF : IHMBuilderController - Fonction initialize le même processus est appliqué ici mais avec une requête et des champs différents
		//Cette fois-ci la classe appliqué au tableview est : ModeleTableScore
		Database bdd = new Database();
		try {
			ResultSet rs = bdd.afficheScore();
			
			while(rs.next())
			{
				oblist.add(new ModeleTableScore(rs.getString("identifiant"), rs.getString("score")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		col_id.setCellValueFactory(new PropertyValueFactory<>("identifiant"));
		col_score.setCellValueFactory(new PropertyValueFactory<>("score"));
		
		table.setItems(oblist);
	}
	
	//Méthode appelé suite à l'appui sur le bouton règle
	public void Rule(ActionEvent event) throws IOException {
		
		//Ouverture d'une nouvelle fenêtre
		Stage stage = new Stage();

	    URL location = getClass().getResource("ruleScreen.fxml");
		FXMLLoader fxmlLoader = new FXMLLoader(location);
		Pane root = (Pane) fxmlLoader.load();
	
		Scene scene = new Scene(root);
		stage.setTitle("Les règles");
		stage.setScene(scene);
		stage.show();
}
	//Méthode appelé suite à l'appui sur le bouton quitter
	public void Quitter(ActionEvent event) {
		//Ferme la fenêtre actuelle
		Stage stage = (Stage)quitBtn.getScene().getWindow();
		stage.close();
}

//Méthode appelé lors de l'appui sur le bouton jouer
public void Jouer(ActionEvent event) throws IOException {
    //Appel la méthode Quitter vu plus haut
	Quitter(null);
	
	//Ouverture d'une nouvelle fenêtre + passage du paramètre id à playControler
	Stage stage = new Stage();

    URL location = getClass().getResource("EcranJeu.fxml");
	FXMLLoader fxmlLoader = new FXMLLoader(location);
	Pane root = (Pane) fxmlLoader.load();

	PlayControler play = fxmlLoader.getController();
	play.myFunction(getId());
	System.out.println("GETTEXT IDFIELD passe à playcontroler" + getId());
	
	Scene scene = new Scene(root);
	stage.setTitle("The Biggest Clicker Competition");
	stage.setScene(scene);
	stage.show();
}

}
