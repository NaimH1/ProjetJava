package client.view;

import java.net.URL;
import java.sql.SQLException;

import com.bd.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.Window;

public class RegisterControler {
    
	//Définition des éléments JavaFX
    @FXML
    public TextField fullNameField;
    
    @FXML
    public TextField emailIdField;
    
    @FXML
    public PasswordField passwordField;
    
    @FXML
    public Button submitButton; 
    
    //Méthode appelé après appui sur bouton confirmer
    public void register(ActionEvent event) throws SQLException{
    
    	//Définition de la fenêtre pour la méthode affichant les erreurs
    	Window owner = submitButton.getScene().getWindow();
    	
    	//Affichage en ligne de commande pour une vérification
    	System.out.println(fullNameField.getText());
    	System.out.println(emailIdField.getText());
    	System.out.println(passwordField.getText());
    	
    	//Vérification des saisies
    	if(fullNameField.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Erreur !", 
                    "Veuillez entrez un mot de passe");
            return;
        }
    	
    	if(emailIdField.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Erreur !", 
                    "Veuillez entrez un e-mail");
            return;
        }
        if(passwordField.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Erreur !", 
                    "Veuillez entrez un mot de passe");
            return;
        }
        
    	String fullName = fullNameField.getText();
    	String emailId = emailIdField.getText();
    	String password = passwordField.getText();
    	
    	//Appel de la bdd et de la méthode pour insérer les lignes dans la bdd
    	Database bdd = new Database();
    	bdd.insertRecord(fullName, emailId, password);
    	//Affichage du message approuvant l'enregistrement
    	showAlert(Alert.AlertType.INFORMATION, owner, "Enregistrement effectue", 
                "Je vous prie de maintenant vous connectez.");
    }
    //Méthode pour les boites de dialogues
    private static void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }
}
