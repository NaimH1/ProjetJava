package client.view;

public class ModeleTableScore {

    String identifiant, score;
    
    public ModeleTableScore(String identifiant, String score) {
        this.identifiant = identifiant;
        this.score = score;
    }

	public String getIdentifiant() {
		return identifiant;
	}

	public void setIdentifiant(String identifiant) {
		this.identifiant = identifiant;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}
   
}
