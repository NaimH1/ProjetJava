package client.view;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;


public class RuleControler {
	
	//Définition des éléments JavaFX
	@FXML
	public Button okBtn;

//Méthode appelé lors de l'appui sur le bouton compris
public void Compris(ActionEvent event) {
	//fermeture de la fenêtre actuelle
	Stage stage = (Stage)okBtn.getScene().getWindow();
	stage.close();
}
}
