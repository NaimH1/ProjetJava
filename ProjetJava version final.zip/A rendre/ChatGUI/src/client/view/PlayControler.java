package client.view;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import com.bd.Database;

import client.network.Client;
import common.Message;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import server.network.ConnectedClient;
import server.network.Server;

public class PlayControler extends ConnectionControler {
	
	//Définition des éléments JavaFX
	@FXML
	public Button clickBtn;
	
	@FXML
	public Label clickLbl;
	
	int nbrClick = 0;
	
	@FXML
	public Label timerLbl;
	
	Timer chrono = new Timer();
	
	@FXML
	public Button rejouerBtn;
	
	@FXML
	public Button sauvBtn;
	
	@FXML
	public Button quitJeuBtn;
	
	//Id contenant l'identifiant de l'utilisateur connectée
	private String id;
	
	public void myFunction(String text)
	{
		this.id = text;
	}
	
	public String getId()
	{
	return id;	
	}

//Méthode appelé lors de l'appui sur bouton Quitter
public void QuitterJeu(ActionEvent event) throws IOException {
	//Ferme la fenêtre actuelle
	Stage stage = (Stage)quitJeuBtn.getScene().getWindow();
	stage.close();
	
	//Ouvre une nouvelle fenêtre en passant le pseudo en paramètre
	Stage newStage = new Stage();

    URL location = getClass().getResource("Game.fxml");
	FXMLLoader fxmlLoader = new FXMLLoader(location);
	Pane root = (Pane) fxmlLoader.load();
	
	GameControler game = fxmlLoader.getController();
	game.myFunction(getId());
	System.out.println("GETTEXT IDFIELD passe à gamecontroler" + getId());
	

	Scene scene = new Scene(root);
	newStage.setTitle("The Biggest Clicker Competition - Menu");
	newStage.setScene(scene);
	newStage.show();
}

//Méthode appelé lors de l'appui sur le bouton Clique
public void Clique(ActionEvent event) throws InterruptedException{
	//Lance le chrono après un clique (le timer est en conflit avec javaFX nécessite potentiellement plusieurs appuis)
	if(nbrClick >= 0)
	{
		//chrono();
		chrono.schedule(new TimerTask() {
			@Override
			public void run() {
				clickBtn.setDisable(true);
				rejouerBtn.setVisible(true);
				sauvBtn.setVisible(true);
				clickBtn.setText("Partie termin�e !");
			}
		}, 10000);
	}
	//Enreigstre le nombre de clique et l'affiche
	nbrClick++;
	String nbrClickString = String.valueOf(nbrClick);
	clickLbl.setText(nbrClickString);
}
//Méthode appelé lors d'appui sur bouton rejouer
public void rejouer(ActionEvent event) {
	//Initialise les variables comme au début
	nbrClick = 0;
	clickBtn.setText("Cliquez ici");
	sauvBtn.setVisible(false);
	rejouerBtn.setVisible(false);
	clickBtn.setDisable(false);
}

public void sauvegarder(ActionEvent event) throws IOException, SQLException
{
	//Appelle la méthode quitterJeu
	QuitterJeu(null);
	
	//Appelle la méthode sauvResultat de la bdd et l'envoi les paramètres dont la requête a besoin
    Database bdd  = new Database();
    String score = String.valueOf(nbrClick);
    bdd.sauvResultat(score, getId());
}
}
