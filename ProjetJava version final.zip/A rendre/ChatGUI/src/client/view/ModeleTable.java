package client.view;

public class ModeleTable {

private String id;

public ModeleTable(String id)
{
	this.id = id;
}

public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}



}
