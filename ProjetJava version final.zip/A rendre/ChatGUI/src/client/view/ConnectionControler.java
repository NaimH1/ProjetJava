package client.view;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;

import com.bd.Database;

import client.network.Client;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.Window;
import client.view.MainViewScene;


public class ConnectionControler extends Application{
    
	//Définition des éléments de JavaFx
    @FXML
    public TextField idField;
    
    @FXML
    public PasswordField passwordField;
    
    @FXML
    public Button connectionButton; 

    @FXML
    public Button createButton;
    
    boolean estConnectee = false;
    
    //Méthode appelé lors de l'appui sur le bouton Connexion
    public void connection(ActionEvent event) throws Exception{
    
    	Window owner = connectionButton.getScene().getWindow();

    	System.out.println("Id :" + idField.getText());
    	
    	System.out.println("Pwd :" + passwordField.getText());
    	
    	//Vérification des saisies
    	if(idField.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Erreur !", 
                    "Veuillez entrez votre identifiant");
            return;
        }
    	//Vérification des saisies
    	if(passwordField.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Erreur !", 
                    "Veuillez entrez votre mot de passe");
            return;
        }
        
    	String id = idField.getText();
    	String password = passwordField.getText();
    	
    	//Vérification si l'utilisateur et le mot de passe existe dans la base de données, renvoi un boolean
    	Database bdd = new Database();
    	estConnectee = bdd.connexionTest(id, password);
    	
    	if(estConnectee)
    	{
    		//Ferme la fenêtre
        	Stage stage = (Stage) idField.getScene().getWindow();
            stage.close();

            try {
            	//Ouvre la fenêtre du chat
            	Stage newStage = new Stage();
            	start(newStage);  
			} catch (Exception e) {
				e.printStackTrace();
			}
    	}else
    	{
    		//Appel d'une boite de dialogue affichant l'erreur
        	showAlert(Alert.AlertType.INFORMATION, owner, "Erreur !", 
                    "Votre identifiant ou votre mot de passe est incorrect.");
    	}
    }
    
    //Méthode appelée lors de l'appui sur le bouton créer un compte
    public void register(ActionEvent event) throws IOException
    {
    	//Ouvre la fenêtre de création de compte
		Stage stage = new Stage();
		URL location = getClass().getResource("registerScreen.fxml");
		FXMLLoader fxmlLoader = new FXMLLoader(location);
		Pane root = (Pane) fxmlLoader.load();

		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.setTitle("Création d'un compte utilisateur");
		stage.show();
    }
    //Méthode de la boite de dialogue affichant les erreurs
    private static void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }

    //Méthode permettant la connexion au serveur et l'ouverture de la fenêtre du chat (passage de l'id à un autre formulaire)
	@Override
	public void start(Stage stage) throws Exception {

		String address = "127.0.0.1";
		int port = 1025;
		System.out.println("L'adresse :" + address);
		System.out.println("Le port :" + port);

		Client client = new Client(address, port);

		URL location = getClass().getResource("IHMBuilder.fxml");
		
		FXMLLoader fxmlLoader = new FXMLLoader(location);
		Pane root = (Pane) fxmlLoader.load();
		IHMBuilderControler controller = fxmlLoader.getController();
		controller.setClient(client);
		client.setViewControler(controller);		

		IHMBuilderControler ihm = fxmlLoader.getController();
		ihm.myFunction(idField.getText());
		System.out.println("GETTEXT IDFIELD" + idField.getText());
		
		Scene scene = new Scene(root);
		stage.setTitle("DelChat - Home");
		stage.setScene(scene);
		stage.show();
		
	}
}




