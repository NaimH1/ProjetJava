package client.view;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import client.view.GameControler;

import com.bd.Database;

import client.network.Client;
import common.Message;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import server.network.ConnectedClient;
import server.network.Server;

public class IHMBuilderControler implements Initializable {

	//Définition des éléments JavaFX
	@FXML
	public Button clearBtn;

	@FXML
	public Button sendBtn;
	
	@FXML
	public Button GameBtn;

	@FXML
	public TextArea textToSend;

	@FXML
	public TextFlow receivedText;

	@FXML
	public ScrollPane scrollReceivedText;
	
	@FXML
	public Button discBtn;
	
	@FXML
	private Button rechargerBtn;
	
	@FXML
	public TableView<ModeleTable> table;
	
	@FXML
	public TableColumn<ModeleTable, String> col_id;

	private Client network;

	@FXML
	public void initialize() {
		scrollReceivedText.vvalueProperty().bind(receivedText.heightProperty());
		scrollReceivedText.setContent(receivedText);
	}
	
	//Création d'une observableList pour l'affichage sur la tableview
	ObservableList<ModeleTable> oblist = FXCollections.observableArrayList();
	
	//Redéfinition de la méthode initialize pour le tableView
	@Override
	public void initialize(URL arg0, ResourceBundle resources) {
		//Appel de la bdd requête affichant les utilisateurs connectée
    	Database bdd = new Database();
    	try {
    		//Récupère les résultats
			ResultSet rs = bdd.estConnectee();
			
			//Ajoute à l'observablelist tous les utilisateurs
			while(rs.next())
			{
				oblist.add(new ModeleTable(rs.getString("identifiant")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	//Définition de la cellule de la table view grâce à la col_id et id de la classe ModeleTable
		col_id.setCellValueFactory(new PropertyValueFactory<>("id"));
		
		//Affiche les items de la oblist dans le tableView
		table.setItems(oblist);
	}
	//Id contenant l'identifiant de l'utilisateur connectée
	private String id;
	
	public void myFunction(String text)
	{
		this.id = text;
	}
	
	public String getId()
	{
	return id;	
	}
	
	//Méthode permettant l'envoi de message
	public void sendMessage(ActionEvent event) {

		System.out.println("send message ");
		Message mess = new Message(getId(), textToSend.getText());

		printNewMessage(mess);

		try {
			network.sendMessage(textToSend.getText());
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
		}
		textToSend.setText("");
	}

	//Méthode permettant la suppression de message non envoyé
	public void clear(ActionEvent event) {
		System.out.println("clearBtn");
		textToSend.setText("");
	}

	public void setClient(Client client) {
		this.network = client;
	}

	public void printNewMessage(Message mess) {

		Platform.runLater(new Runnable() {
			@Override
			public void run() {

				Label text = new Label("\n" + mess.toString());
				double value = receivedText.getPrefWidth() - 20;
				System.err.println("message : " + text.getText());
				text.setPrefWidth(value);
				text.setAlignment(Pos.CENTER_LEFT);

				receivedText.getChildren().add(text);
			}
		});
	}
	
	//Méthode appelé lors d'un appui sur le bouton "Menu Jeu" (Ouvre une nouvelle fenêtre en passant le paramètre de l'utilisateur connecté)
	public void Game(ActionEvent event) throws IOException {
		
		Stage stage = new Stage();
		URL location = getClass().getResource("Game.fxml");
		FXMLLoader fxmlLoader = new FXMLLoader(location);
		Pane root = (Pane) fxmlLoader.load();
		
		GameControler game = fxmlLoader.getController();
		game.myFunction(getId());
		System.out.println("GETTEXT IDFIELD passe à gamecontroler" + getId());

		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

		}
	//Permet de rechargr la tableview des utilisateurs connectés
	public void recharger(ActionEvent event) throws IOException, SQLException {
		//Appel de la bdd requête affichant les utilisateurs connectée
    	Database bdd = new Database();
    	try {
    		//Récupère les résultats
			ResultSet rs = bdd.estConnectee();
			oblist.clear();
			//Ajoute à l'observablelist tous les utilisateurs
			while(rs.next())
			{
				oblist.add(new ModeleTable(rs.getString("identifiant")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	//Définition de la cellule de la table view grâce à la col_id et id de la classe ModeleTable
		col_id.setCellValueFactory(new PropertyValueFactory<>("id"));
		
		//Affiche les items de la oblist dans le tableView
		table.setItems(oblist);
	}
	//Méthode appelé lors de l'appui sur le bouton déconnexion
	public void deconnexion(ActionEvent event) throws IOException, SQLException {
		//Ferme la fenêtre actuelle
		Stage oldstage = (Stage)GameBtn.getScene().getWindow();
		oldstage.close();
		
		//Ouvre une nouvelle fenêtre
		Stage stage = new Stage();
		URL location = getClass().getResource("EcranConnexion.fxml");
		FXMLLoader fxmlLoader = new FXMLLoader(location);
		Pane root = (Pane) fxmlLoader.load();
		

		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		
		//Passe la colonne estconnectee de la bdd à false
		Database bdd = new Database();
		bdd.deconnexion(getId());
	}
	}
	
