package com.bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import client.view.ConnectionControler;
import javafx.scene.control.Alert;
import javafx.stage.Window;

public class Database {
	
	//Variable permettant la connexion � la base de donn�es
	private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/java_chat?useSSL=false";
	private static final String DATABASE_USERNAME = "root";
	private static final String DATABASE_PASSWORD = "";
	
	//Requ�te permettant l'insertion des donn�es utilisateurs lors de l'inscription
	private static final String INSERT_QUERY = "INSERT INTO registration (identifiant, password, email, estconnectee) VALUES (?, ?, ?, 'false')";
	private static final String INSERT_QUERY2 = "INSERT INTO scoregame (identifiant, score) VALUES (?, 0)";
	private static final String SELECT_QUERY = "SELECT * FROM registration WHERE identifiant = ? AND password = ?";
	private static final String SELECT_QUERY2 = "SELECT identifiant FROM registration WHERE estconnectee = 'true'";
	private static final String SELECT_QUERY3 = "SELECT identifiant, score FROM scoregame ORDER BY score DESC";
	private static final String UPDATE_QUERY = "UPDATE registration SET estconnectee = 'true' WHERE identifiant = ? ";
	private static final String UPDATE_QUERY2 = "UPDATE registration SET estConnectee = 'false' WHERE identifiant = ? ";
	private static final String UPDATE_QUERY3 = "UPDATE scoregame SET score = ? WHERE identifiant = ?";

//Gère la création de compte
public void insertRecord(String fullName, String emailId, String password) throws SQLException {
	
    	// �tape 1 : �tablir une connexion avec la bdd
    	try (Connection connection = DriverManager
        .getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);

        // �tape 2 : Cr�er une d�claration � l'aide de l'objet de connexion
        PreparedStatement preparedStatement = connection.prepareStatement(INSERT_QUERY2)) {
        preparedStatement.setString(1, fullName);

        System.out.println(preparedStatement);
        // // Etape 3 : Ex�cuter la requ�te ou mettre � jour la requ�te
        preparedStatement.executeUpdate();
       
    	} catch (SQLException e) {
        printSQLException(e);
    	}
		
        // �tape 1 : �tablir une connexion avec la bdd
        try (Connection connection = DriverManager
            .getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);

            // �tape 2 : Cr�er une d�claration � l'aide de l'objet de connexion
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_QUERY)) {
            preparedStatement.setString(1, fullName);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, emailId);

            System.out.println(preparedStatement);
            // // Etape 3 : Ex�cuter la requ�te ou mettre � jour la requ�te
            preparedStatement.executeUpdate();
           
        } catch (SQLException e) {
            printSQLException(e);
        }
}
//Gère déconnexion
public void deconnexion(String identifiant) throws SQLException {
	 // �tape 1 : �tablir une connexion avec la bdd
    try (Connection connection = DriverManager
        .getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);

        // �tape 2 : Cr�er une d�claration � l'aide de l'objet de connexion
        PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_QUERY2)) {
        preparedStatement.setString(1, identifiant);

        System.out.println(preparedStatement);
        // // Etape 3 : Ex�cuter la requ�te ou mettre � jour la requ�te
        preparedStatement.executeUpdate();
       
    } catch (SQLException e) {
        printSQLException(e);
    }
}

//Gère la sauvegarde des résultats
public void sauvResultat(String score, String identifiant) throws SQLException {
	
    // �tape 1 : �tablir une connexion avec la bdd
    try (Connection connection = DriverManager
        .getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);

        // �tape 2 : Cr�er une d�claration � l'aide de l'objet de connexion
        PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_QUERY3)) {
        preparedStatement.setString(1, score);
        preparedStatement.setString(2, identifiant);

        System.out.println(preparedStatement);
        // // Etape 3 : Ex�cuter la requ�te ou mettre � jour la requ�te
        preparedStatement.executeUpdate();
       
    } catch (SQLException e) {
        printSQLException(e);
    }
}
//Gère l'affichage dans la tableview 1
public ResultSet estConnectee() throws SQLException {
	
	ResultSet resultat = null;
	
    // �tape 1 : �tablir une connexion avec la bdd
    try (Connection connection = DriverManager
        .getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);

        // �tape 2 : Cr�er une d�claration � l'aide de l'objet de connexion
        PreparedStatement preparedStatement = connection.prepareStatement(SELECT_QUERY2)) {


        System.out.println(preparedStatement);
        // // Etape 3 : Ex�cuter la requ�te ou mettre � jour la requ�te
        resultat = preparedStatement.executeQuery();
        
       
    } catch (SQLException e) {
        printSQLException(e);
    }
	return resultat;
}
//Gère l'affichage des scores dans la tableview2
public ResultSet afficheScore() throws SQLException {
	
	ResultSet resultat = null;
	
    // �tape 1 : �tablir une connexion avec la bdd
    try (Connection connection = DriverManager
        .getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);

        // �tape 2 : Cr�er une d�claration � l'aide de l'objet de connexion
        PreparedStatement preparedStatement = connection.prepareStatement(SELECT_QUERY3)) {

        System.out.println(preparedStatement);
        // // Etape 3 : Ex�cuter la requ�te ou mettre � jour la requ�te
        resultat = preparedStatement.executeQuery();
        
       
    } catch (SQLException e) {
        printSQLException(e);
    }
	return resultat;
}
//Gère le test de connexion
public boolean connexionTest(String id, String password) throws SQLException
{
	ResultSet resultat = null;
	//Utiliser pour la list view de l'écran d'accueil
	//Enregistre dans la base de données la personne comme connectée
	try (Connection connection = DriverManager
            .getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);
			
			// �tape 2 : Cr�er une d�claration � l'aide de l'objet de connexion
            PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_QUERY)) {
            preparedStatement.setString(1, id);
            
            System.out.println(preparedStatement);
            // // Etape 3 : Ex�cuter la requ�te 
            preparedStatement.executeUpdate();
	}
	
	// �tape 1 : �tablir une connexion avec la bdd
	try (Connection connection = DriverManager
            .getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);
			
			// �tape 2 : Cr�er une d�claration � l'aide de l'objet de connexion
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_QUERY)) {
            preparedStatement.setString(1, id);
            preparedStatement.setString(2, password);
            
            System.out.println(preparedStatement);
            // // Etape 3 : Ex�cuter la requ�te et enregistrer le résultat
            resultat = preparedStatement.executeQuery();
} catch (SQLException e) {
    printSQLException(e);
}
    if(resultat.next())
    	return true;
    else 
    	return false;
}

		//Fonction permettant l'affichage des exceptions sur la console
        public static void printSQLException(SQLException ex) {
            for (Throwable e: ex) {
                if (e instanceof SQLException) {
                    e.printStackTrace(System.err);
                    System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                    System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                    System.err.println("Message: " + e.getMessage());
                    Throwable t = ex.getCause();
                    while (t != null) {
                        System.out.println("Cause: " + t);
                        t = t.getCause();
                    }
                }
            }
        }
}