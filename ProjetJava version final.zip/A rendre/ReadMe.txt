(1 - Télécharger XAMPP : https://www.apachefriends.org/fr/download.html
2 - Lancez xampp-control.exe
3 - Démarrez Apache et MySQL
4 - Cliquez sur le bouton "Admin" de la rangée MySQL)
5 - Exécutez le code SQL se situant dans le fichier BDD.txt
6 - Configurer potentiellement les identifiants et le mot de passe de la base de données dans le fichier Database.java du package com.bd
7 - Lancez eclipse
8 - Configurez potentiellement les chemins d'accès au fichier
9- Lancez "MainServerP"
10 - Lancez "debApp"   